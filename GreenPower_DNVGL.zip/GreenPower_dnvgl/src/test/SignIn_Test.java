package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * To validate more exhaustive the functions of our web, I would do some Unit Test to be sure that later, 
 * 	when we have all the application developed, we can validate any change without review all the code step by step.
 *	
*/

import org.junit.jupiter.api.Test;
import util.Constants;

class SignIn_Test {
	
	/**
	 * Test to validate the email format is correct.
	 * 
	 */

	@Test
	void EmailFormatCorrect() {
		
		Constants cons = new Constants();
		
		// assert statements

    	 Pattern pattern = Pattern
                 .compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                         + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
    	 
    	 assertNotNull(cons.getEMAIL(), "The email must be not null");
    	 
         Matcher mather = pattern.matcher(cons.getEMAIL());
         
         assertTrue( mather.find(),"The email implements is correct");

	}
	
	/**
	 * Test to validate when we do the SignIn, we do it correctly and the profile is loaded. 
	 * 
	 */

	@Test
	void SignInCorrectly() {
		assertTrue( true,"");
	}
	
	
	
	

}
