package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * 
 * To validate more exhaustive the functions of our web, I would do some Unit Test to be sure that later, 
 * 	when we have all the application developed, we can validate any change without review all the code step by step.
 *	
*/


class WebConnection_Test {
	
	/**
	 *  In this method i want to check if the connection with the server is up 
	 *  or we have some problems like delay or similar
	 */
	@Before
	void isServerUp() {

		fail("Not yet implemented");
	}
	
	
	/**
	 *  In this method i want to check if the client has the plugins necessary to run the website. 
	 *  In case that he is navigating by mobile or tablet, maybe he will need some plugins to keep navigating correctly.
	 */
	@Test
	void PluguinsLoaded() {
		fail("Not yet implemented");
	}
		
	

}
