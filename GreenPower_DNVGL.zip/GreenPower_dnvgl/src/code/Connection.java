package code;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import util.WebElementsFunctions;
import util.CommonFunctions;
import util.Constants;


public class Connection {
    
	/**
	 * @throws InterruptedException 
	 * 
	 * In this method i will validate:
	 * 	 that i can navigate to the signin website
	 * 	 if i change the languague to Spanish, the website load it correctly.
	 * 	 If i try to login with a user that is not register a notify will appears
	 */
    public boolean SignIn(String ID, String PWD, Constants constant, WebDriver driver, 
    		WebElementsFunctions element ) throws InterruptedException {
    	
        try {    
    	    
        	// validate that 
    	    element.getElement(driver, By.xpath("//*[@id=\"dnvgl\"]/header/section/a")).click(); 
    	    
    	    element.getElement(driver, By.id("selectLanguage")).sendKeys("Espa�ol");
    	    
    	    element.getElement(driver, By.id("userNameInput")).sendKeys(ID);
    	    
    	    element.getElement(driver, By.id("passwordInput")).sendKeys(PWD);
    	    
    	    element.getElement(driver, By.id("submitButton")).click();
    	    
    	    Thread.sleep(3000);
    	    
    	    if(element.getElement(driver, By.id("errorText")).isDisplayed()) {
    	    	return false;
    	    }else {
    	    	return true;
    	    }
    	  
        }
        catch(Exception e) {
        	e.printStackTrace();
        	return false;
        	
        }

    }
    
    public void SignOut() {}
    
    
    public void Register(String ID, String PWD, Constants constant, WebDriver driver, 
    		WebElementsFunctions element ) throws InterruptedException {
    	
    	 try{   
     	    
     	    element.getElement(driver, By.id("newUserProfile")).click();
     	    
     	    /**
     	     *  here will be the code for do a register
     	     * 
     	     */
     	    
     	    Thread.sleep(3000);

         }
         catch(Exception e) {
         	e.printStackTrace();

         	
         }
    	
    	
    }
    

    
}
