/**
 * 
 */
package code;



import org.openqa.selenium.WebDriver;

import util.CommonFunctions;
import util.Constants;
import util.WebElementsFunctions;


/**
 * @author Miguel
 * 
 * This program will do a simple Login on the DNVGL web. For do this, we implements the class 
 * 		WebWlement for override and do some modifications on the methods.
 * The main code only will inicializate the objects and call the class that will do the functions.
 *
 */
public class mainCode {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		
		String result =  "";
	    WebDriver driver = null;
	    
	    CommonFunctions commonFunctions =  new CommonFunctions();
		Connection connect = new Connection();
		Constants constant =  new Constants();
		
		driver = commonFunctions.selectDriver(constant.getDRIVER(), constant.getDRIVER_PATH());
		WebElementsFunctions element = commonFunctions.selectElement();
		
		commonFunctions.OpenWeb(driver, element, constant.getDNVGL_DIR());

		result = (connect.SignIn(constant.getEMAIL(), constant.getPASSWORD(), constant, driver, element ))? "SingIn correctly" : "Error to SignIn";
		
		System.out.println(result);
		
		connect.Register(constant.getEMAIL(), constant.getPASSWORD(), constant, driver, element);
		
		driver.close();
		
		
	}
	
	

}
