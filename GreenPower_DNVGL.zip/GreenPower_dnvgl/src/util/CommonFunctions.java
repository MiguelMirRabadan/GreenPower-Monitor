package util;



import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class CommonFunctions {
	
	public CommonFunctions() {
		
	}

    //Inicializa el WebDriver
    public WebDriver selectDriver(String DRIVER, String DRIVER_PATH) throws Exception {

        System.setProperty(DRIVER, DRIVER_PATH);
        WebDriver driver = new ChromeDriver();
        
        return driver;
    }
    //Inicializa el SpecialWebElement
    public WebElementsFunctions selectElement() throws Exception {

        WebElementsFunctions element = new WebElementsFunctions();
        return element;
    }

    //Log en ZCAS con usuario 
    public void OpenWeb(WebDriver driver, WebElementsFunctions element, String DNVGL_DIR) throws InterruptedException {
        driver.get(DNVGL_DIR);
        driver.manage().window().maximize();
    }
    
    
    public void switchFrame(WebDriver driver) throws InterruptedException{
        
        driver.switchTo().defaultContent();
        
        try {
            
            List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
            System.out.println(iframes.size());
            for (WebElement iframe : iframes) {
                if (iframe.getAttribute("class").equals("runtime-popup") && iframes.size()==3) {
                    driver.switchTo().frame(iframe);
                    break;
                }
                if(iframe.getAttribute("class").equals("content-control-iframe") && iframes.size()==2) {
                    driver.switchTo().frame(iframe);
                    break;
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    


 

}
