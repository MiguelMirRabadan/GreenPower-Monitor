package util;



/**
 * @author Miguel
 * 
 * This Class will contains all the variables that never
 * 	changes and are important to be separate of the rest of code.
 *
 */

public class Constants {

       
    //Drivers
    private final String DRIVER = "webdriver.chrome.driver";
    private final String DRIVER_PATH = "C:\\Users\\Pccom\\eclipse-workspace\\chromedriver.exe";
    private final String DNVGL_DIR = "https://www.dnvgl.com/#";

    //User info
    private final String EMAIL = "miguel_mir.92@hotmail.com";
    private final String PASSWORD = "Password1234!";
    
    public Constants() {}
    
    
	public String getDRIVER() {
		return this.DRIVER;
	}
	public String getDRIVER_PATH() {
		return this.DRIVER_PATH;
	}
	public String getDNVGL_DIR() {
		return this.DNVGL_DIR;
	}
	public String getEMAIL() {
		return this.EMAIL;
	}
	public String getPASSWORD() {
		return this.PASSWORD;
	}

	
}
