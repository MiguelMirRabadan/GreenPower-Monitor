package util;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * @author Miguel
 * 
 * This Class will contain all the methods override of the WebElemnt class.
 *
 */
public class WebElementsFunctions implements WebElement{
	
	// FIELDS and CONSTRUCTORS
    private WebElement element;
    private WebDriver driver;
    private By locator;
    private final long INTERVAL = 500;
    
    public WebElementsFunctions() {
    	this.setDriver(null);
    	this.setElement(null);
    	this.setLocator(null);
    }

    
//	SETTERS
	public void setElement(WebElement element) {
		this.element = element;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public void setLocator(By locator) {
		this.locator = locator;
	}

// GETTERS
	public By getLocator() {
		return this.locator;
	}
	
	public WebDriver getDriver() {
		return this.driver;
	}

	 public WebElement getElement(WebDriver driver, By webAddress) throws InterruptedException, NoSuchElementException {
		 
     this.setDriver(driver);
     this.setLocator(webAddress);
     
     WebElement elementFound = null;

     // Looks for the element.
     try {
         elementFound = driver.findElement(webAddress);
         if (elementFound.isDisplayed()) {
        	 this.setElement(elementFound);
         }
         else {
        	 throw new NoSuchElementException("Element not Found: " + locator);
         }
     }
     catch (Exception e) {
    	 e.printStackTrace();
     }
     
     return this;

 }

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		this.element.clear();
		
	}
	
	@Override
	public void click() {
		// Here i will put the code for do some comprovations when we click an element calling the correct methods, like:
		// - if the element isEnable
		// - if the element isClickeable
		// - if an element is not unfolding.
		// And Throw a custom exceptions when a issue appears
		
		
		// An example of how i want to click

        WebDriverWait wait = new WebDriverWait(this.getDriver(), (long) 5);

        try {
            wait.until(ExpectedConditions.elementToBeClickable(this.element));
            this.element.click();
        }
        catch (Exception e) {
        	//throw new NoSuchElementException("Element was not clicked: " + locator);
            try {
				Thread.sleep(this.INTERVAL);
				this.getElement(driver, locator);
				
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
        }

	}

	@Override
	public WebElement findElement(By arg0) {
		// TODO Auto-generated method stub
		return driver.findElement(arg0);
	}

	@Override
	public List<WebElement> findElements(By arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAttribute(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCssValue(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Point getLocation() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Rectangle getRect() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Dimension getSize() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTagName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getText() {
		// TODO Auto-generated method stub
		return this.element.getText();
	}

	@Override
	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return this.element.isDisplayed();
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return this.element.isEnabled();
	}

	@Override
	public boolean isSelected() {
		// TODO Auto-generated method stub
		return this.element.isSelected();
	}


	@Override
	public void submit() {
		this.element.submit();
		
	}

	@Override
	public void sendKeys(CharSequence... arg0) {
		 this.element.sendKeys(arg0);

	}
	
	@Override
	public <X> X getScreenshotAs(OutputType<X> arg0) throws WebDriverException {
		// TODO Auto-generated method stub
		return null;
	}



}
